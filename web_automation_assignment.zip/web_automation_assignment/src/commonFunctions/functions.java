package commonFunctions;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class functions {
	
	/***************************************************************************
	*Name:			fn_GetTimeStamp
	*Description:	Get timestamp, format DD mmm YYYY hh_mm_ss AM/PM
	*Arguments:		N/A
	*Return:		DateValue
	*************************************************************************/		
	public static String fn_GetTimeStamp(){
		
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());		
		return timeStamp;
	}
	
	/***************************************************************************
	*Name:			fn_TakeScreenshot
	*Description:	Take screenshot of the application in testing
	*Arguments:		driver, destfilePath
	*Return:		destfilePath
	***************************************************************************/	         	
	public static String fn_TakeSnapshot(String tc,WebDriver driver, String destFilePath) throws IOException{
		
		String TS=fn_GetTimeStamp();	
		TakesScreenshot tss=(TakesScreenshot) driver;
		File srcfileObj= tss.getScreenshotAs(OutputType.FILE);
		destFilePath=destFilePath+ tc + "_" + TS + ".jpg";
		File DestFileObj=new File(destFilePath);
		FileUtils.copyFile(srcfileObj, DestFileObj);
		return destFilePath;
	}

	/***************************************************************************
	*Name:			fn_InitializeResultsFolder
	*Description:	Initialize automation results folder
	*Arguments:		destFilePath
	*Return:		N/A
	***************************************************************************/	     	
	public static String fn_InitializeResultsFolder(String destFilePath) throws IOException{
		
		File destFile = new File(destFilePath);
		if(! destFile.exists()) {
			destFile.mkdir();			
		}
		return destFilePath;
	}	
	
	/***************************************************************************
	*Name:			fn_PopulateFields
	*Description:	Populate the text field
	*Arguments:		driver, attrType, fieldName, fieldValue
	*Return:		fieldValue
	***************************************************************************/	     		
	public static String fn_PopulateFields(WebDriver driver,String attrType, String fieldName, String fieldValue) {
		
		WebElement searchbox = driver.findElement(By.xpath("//input[@" + attrType + "='" + fieldName + "']"));
		JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
		myExecutor.executeScript("arguments[0].value='"+ fieldValue + "';", searchbox);
		return fieldValue;
		
	}

	/***************************************************************************
	*Name:			fn_ClickBtn
	*Description:	Populate the text field
	*Arguments:		driver, attrType, btnName
	*Return:		fieldValue
	***************************************************************************/	     		
	public static String fn_ClickBtn(WebDriver driver,String attrType,String btnName) {
		
		WebElement btn = driver.findElement(By.xpath("//button[@" + attrType + "='" + btnName + "']"));
		btn.click();
		return btnName;
		
	}	
	
	/***************************************************************************
	*Name:			fn_ClickLink
	*Description:	Populate the text field
	*Arguments:		driver, attrType, lnkName
	*Return:		fieldValue
	***************************************************************************/
	public static String fn_ClickLink(WebDriver driver,String attrType,String lnkName) {
		
		WebElement lnk = driver.findElement(By.xpath("//*[@" + attrType + "='" + lnkName + "']"));			
		lnk.click();
		return lnkName;
		
	}
	
	/***************************************************************************
	*Name:			fn_PageChecker
	*Description:	Populate the text field
	*Arguments:		driver, attrType, lnkName
	*Return:		fieldValue
	***************************************************************************/
	public static Boolean fn_PageChecker(WebDriver driver,String expectedTitle) {
		
        // get the actual value of the title
        String actualTitle = driver.getTitle();
        Boolean blnCheck;
		/*
         * compare the actual title of the page with the expected one and print
         * the result as "Passed" or "Failed"
         */
        if (actualTitle.contentEquals(expectedTitle)){
        	blnCheck = true;
        } else {
        	blnCheck = false;
        }		
        return blnCheck;
	}	
	
	/***************************************************************************
	*Name:			fn_OpenUrl
	*Description:	Populate the text field
	*Arguments:		driver, baseUrl, blnMaximize
	*Return:		fieldValue
	***************************************************************************/	     		
	public static String fn_OpenUrl(WebDriver driver,String baseUrl,Boolean blnMaximize) {
		
		driver.get(baseUrl);		
		if(blnMaximize == true) {
			driver.manage().window().maximize();	
		}		
		return baseUrl;
		
	}	
}
